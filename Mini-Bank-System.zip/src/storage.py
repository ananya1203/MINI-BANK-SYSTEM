print('Storage placeholder')
