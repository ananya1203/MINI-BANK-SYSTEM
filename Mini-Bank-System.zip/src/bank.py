print('Bank logic placeholder')
