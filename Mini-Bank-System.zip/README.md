# Mini Banking Simulation System

A console-based mini banking system for BYOP submission.

## Features
- Create account
- Deposit
- Withdraw
- Transfer money
- Transaction history
- Search accounts
- List all accounts

## Run
python src/main.py
