Problem statement for BYOP mini banking project.
